package dd_util;



public class TestConfig{


	
	public static String server="smtp.gmail.com";
	public static String from = "anagre77@gmail.com";
	public static String password = "9970814338";
	public static String[] to ={"vaishalibakale@gmail.com"};
	public static String subject = "Sending Zip file of Data Driven Framework...";
	
	public static String messageBody ="Thank you Mam...";
	public static String attachmentPath=System.getProperty("user.dir")+"//Reports.zip";
	public static String attachmentName="reports.zip";
	
	
	
	
	
	
	
	
	
}
