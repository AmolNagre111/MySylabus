package FB_dd_tests;

import org.testng.annotations.Test;

import FB_dd_core.CoreTest;
import FB_dd_util.testUtil;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;



public class LoginTest extends CoreTest{
	
	// checking Skip testcases or not
	@BeforeTest
	public void isSkip() throws InterruptedException
	{
		Thread.sleep(5000L);
		
		if(!testUtil.isExecutable("LoginTest"))
		{
			throw new SkipException("Skipping the TestCase as runmode is set to No");
		}
	}
	
	@Test(dataProvider="getData")
	public void doLogin(String email,String password) throws IOException
	{
		try{
		app_logs.debug("Enetering Login Test and Enter Credentials");
		// username of FB
		driver.findElement(By.xpath(object.getProperty("username"))).sendKeys(email);
		
		//Password of FB
		driver.findElement(By.xpath(object.getProperty("password"))).sendKeys(password);
		
		// LoginButton 
		driver.findElement(By.xpath(object.getProperty("login"))).click();
		}catch(Throwable t){
			testUtil.captureScreenshot("LoginTest");
			Assert.assertTrue(false,t.getMessage());
		}
	
	}
	
	@DataProvider
	public static Object[][] getData()
	{
		return testUtil.getData("LoginTest");
	}
}